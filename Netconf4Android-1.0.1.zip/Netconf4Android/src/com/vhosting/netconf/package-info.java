/**
 * From this package you can access the basic operations 
 * of Netconf as Java classes. Or thanks to the class Opetation 
 * implement new operations for specific capability.
 */
package com.vhosting.netconf;

