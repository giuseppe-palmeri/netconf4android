/**
 * This is the entry point of a Netconf application 
 * over SSH-2.
 * 
 * Contains everything related to the 
 * specific SSH-2 transport protocol of Netconf messages.
 * 
 */
package com.vhosting.netconf.transport.ssh;

