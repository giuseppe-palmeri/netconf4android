/**
 * Contains everything related to the 
 * transport protocol of Netconf messages.
 */
package com.vhosting.netconf.transport;